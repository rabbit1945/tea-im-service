<?php


namespace app;
/**
 * 手机号加*
 * Class FilterMobile
 * @package app
 */

class FilterMobile extends Filter
{

    /**
     * @param $message
     * @return mixed
     */
    public function filter($message)
    {
        // TODO: Implement filter() method.
        $message = preg_replace("/(1[3|5|7|8]\d)\d{4}(\d{4})/i", "$1****$2", $message);
        if ($this->next) {
            return $this->next->filter($message);
        } else {
            return $message;
        }

    }
}
