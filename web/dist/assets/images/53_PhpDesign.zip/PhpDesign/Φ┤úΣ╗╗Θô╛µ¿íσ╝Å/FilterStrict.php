<?php
namespace app;

/**
 * 严禁词汇
 * Class FilterStrict
 * @package app
 */

class FilterStrict extends Filter
{

    /**
     * @param $message
     * @return mixed
     * @throws \Exception
     */
    public function filter($message)
    {
        // TODO: Implement filter() method.
        foreach (['枪X', '弹X', '毒X'] as $v) {
            if (strpos($message,$v)) {
                throw new \Exception('该信息包含敏感词汇！');

            }
        }

        if ($this->next) {
            return $this->next->filter($message);
        } else {
            return $message;
        }

    }
}
