<?php
/**
 * 语句过滤抽象接口
 * Class Filter
 */
namespace app;

abstract class Filter
{
    protected $next;
    public function setNext($next) {
        $this->next = $next;
    }

    abstract public function filter($message);

}
