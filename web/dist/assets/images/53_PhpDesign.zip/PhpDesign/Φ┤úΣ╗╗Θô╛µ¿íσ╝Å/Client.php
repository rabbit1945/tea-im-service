<?php


namespace app;
require __DIR__ . '/./vendor/autoload.php';

class Client
{



    public function index() {
        $f1 = new FilterStrict();
        $f2 = new FilterWarning();
        $f3 = new FilterMobile();


        $f1->setNext($f2);
        $f2->setNext($f3);

        $m1 = "现在开始测试链条1：语句中不包含敏感词，需要替换掉打架这种词，然后给手机号加上星：13333333333，这样的数据才可以对外展示哦";
        echo $f1->filter($m1);
        echo PHP_EOL;

//        $m2 = "现在开始测试链条2：这条语句走不到后面，因为包含了毒X，直接就报错了！！！语句中不包含敏感词，需要替换掉打架这种词，然后给手机号加上星：13333333333，这样的数据才可以对外展示哦";
//        echo $f1->filter($m2);
//        echo PHP_EOL;



    }

}

(new Client())->index();


