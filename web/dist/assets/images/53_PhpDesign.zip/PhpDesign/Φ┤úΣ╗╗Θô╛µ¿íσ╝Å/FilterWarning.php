<?php


namespace app;

/**
 * 警告词汇
 * Class FilterWarning
 * @package app
 */
class FilterWarning extends Filter
{

    /**
     * @param $message
     * @return mixed
     */
    public function filter($message)
    {
        // TODO: Implement filter() method.
        $message = str_replace(['打架', '丰胸', '偷税','共产党'],'*',$message);
        if ($this->next) {
            return $this->next->filter($message);
        } else {
            return $message;
        }
    }
}

