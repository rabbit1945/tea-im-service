<?php

/**
 * Class Client
 */
namespace app;
require __DIR__ . '/./vendor/autoload.php';

class Client
{
    public function index() {
//        $circle = new Circle(new Point(1,3),2);
//        $circle->printCenter();
//        print_r($circle->area());
          $di = new Di();
          $di->invoke(Circle::class);


    }

}


(new Client() ) -> index();
