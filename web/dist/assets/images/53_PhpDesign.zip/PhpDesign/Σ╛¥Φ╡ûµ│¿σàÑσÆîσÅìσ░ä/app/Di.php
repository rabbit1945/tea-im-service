<?php

namespace app;
use ReflectionException;
use ReflectionFunctionAbstract;

class Di
{

    /**
     * 调用
     * @param $callable
     * @param array $vars
     * @throws ReflectionException
     */
    public function invoke($callable, array $vars = []) {

        try {
            $this->invokeClass($callable, $vars);
        } catch (\ReflectionException $e) {
            throw new \ReflectionException('class not exists: ' . $callable, $callable, $e);
        }

    }

    /**
     * 调用反射支持实例化
     * @param string $class
     * @param array $vars
     * @throws ReflectionException
     */
    public function invokeClass(string $class, array $vars = []) {

        // 初始化反射类
        try {
            $reflect = new \ReflectionClass($class);

        } catch (\ReflectionException $e) {
            throw new \ReflectionException('class not exists: ' . $class, $class, $e);

        }
        //  获取构造函数
        $constructor = $reflect->getConstructor();
        //  获取参数
        $args = $constructor ? $this->bindParams($constructor,$vars) : [];


    }

    /**
     * 绑定参数
     * @param ReflectionFunctionAbstract $reflect
     * @param array $vars
     */
    public function bindParams(ReflectionFunctionAbstract $reflect, array $vars = []) {
        //  获取参数数目
        if ($reflect->getNumberOfParameters() == 0) {
            return [];
        }

        $params = $reflect->getParameters();

        $args   = [];

        foreach ($params as $param) {

            // 名称
            $name = $param->getName();
            // 类型
            $reflectionType = $param->getType();

            if ($reflectionType && $reflectionType instanceof \ReflectionNamedType && $reflectionType->isBuiltin() == false ) {


            }



        }




    }

}


