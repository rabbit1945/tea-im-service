<?php

/**
 * 坐标点
 * Class Point
 */
namespace app;
class Point
{
    public $x;
    public $y;
    public function __construct($x,$y) {
        $this->x = $x;
        $this->y = $y;
    }

}
