<?php

require_once './CarInfo.php';
require_once './SpeedRankDecorator.php';
require_once './WheelDeployDecorator.php';
class Client
{
    public function index() {
        $carInfo = new CarInfo();
        // 速度排名
        $speedRank = new SpeedRankDecorator($carInfo);
        //  驱动
        $wheelDeploy = new WheelDeployDecorator($speedRank);

        $wheelDeploy->displayCarInfo();

        $wheelDeploy->signContract("土豪");

    }

}


(new Client())->index();
