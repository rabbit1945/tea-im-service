<?php
/**
 * 装饰器类
 * Class Decorator
 */

class Decorator extends  CarSale
{
    protected $_component;
    public function __construct($component)
    {
        $this->_component = $component;

    }


    /**
     * @return mixed
     */
    public function displayCarInfo()
    {
        // TODO: Implement displayCarInfo() method.
        return $this->_component->displayCarInfo();
    }

    /**
     * @param $customerName
     * @return mixed
     */
    public function signContract($customerName)
    {
        // TODO: Implement signContract() method.
        return $this->_component->signContract($customerName);
    }
}
