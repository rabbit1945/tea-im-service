<?php
/**
 * 扩展新的功能。驱动介绍
 * Class SpeedRankDecorator
 */
require_once './Decorator.php';
class WheelDeployDecorator extends Decorator
{
    public function __construct($component)
    {
        parent::__construct($component);
    }

    private function showWheelSys() {

        echo("后驱车，让你漂移分分钟，就问对方怕不怕\n");

    }

    public function displayCarInfo() {
        $this->showWheelSys();
        parent::displayCarInfo();
    }

}
