<?php
/**
 * 销售汽车抽象类
 * Class CarSale
 */

abstract class CarSale {
    /**
     * 推销车的详情
     */
    abstract public function displayCarInfo();

    /**
     * 客户签订劳动合同
     * @param $customerName // 客户名称
     */
    abstract public function signContract($customerName);

}
