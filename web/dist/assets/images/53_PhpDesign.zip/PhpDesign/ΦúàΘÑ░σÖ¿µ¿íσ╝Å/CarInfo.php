<?php
/**
 * 定义要装饰的类
 * Class CarInfo
 */
require_once './CarSale.php';
class CarInfo extends CarSale
{


    /**
     * @return mixed
     */
    public function displayCarInfo()
    {
        // TODO: Implement displayCarInfo() method.
        echo("日本丰田GTR\n");
        echo("百公里加速1秒\n");
        echo("油耗偏高\n");
        echo("后驱涡轮增压\n");
        echo("内饰豪华\n");
        echo("发动机噪音偏大\n");
        echo("不支持电动座椅，后视镜加热\n");
    }

    /**
     * @param $customerName
     * @return mixed
     */
    public function signContract($customerName)
    {
        // TODO: Implement signContract() method.
        echo ("客户签约销售合同， 付款人：" .$customerName);
    }
}
