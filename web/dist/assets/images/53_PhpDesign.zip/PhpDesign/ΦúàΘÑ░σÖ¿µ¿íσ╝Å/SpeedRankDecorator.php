<?php
/**
 * 扩展新的功能。速度排名介绍
 * Class SpeedRankDecorator
 */
require_once './Decorator.php';
class SpeedRankDecorator extends Decorator
{
    public function __construct($component)
    {
        parent::__construct($component);
    }

    private function showSpeedRank() {

        echo("这个车百公里加速快，外观吊炸天，装逼神器啊，大兄弟\n");

    }

    public function displayCarInfo() {
        $this->showSpeedRank();
        parent::displayCarInfo();
    }

}
