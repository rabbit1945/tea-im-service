<?php

echo $_SESSION['admin'];
