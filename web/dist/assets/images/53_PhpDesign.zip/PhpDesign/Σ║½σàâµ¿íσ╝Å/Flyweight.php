<?php
/**
 * 定义抽象类
 * 通常是一个接口或者抽象类，
 * 在抽象享元类中声明了具体享元类公共的方法，
 * 这些方法可以向外界提供享元对象的内部数据（内部状态），
 * 同时也可以通过这些方法来设置外部数据（外部状态）
 */
namespace app;
/**
 * Class Flyweight
 * @package app
 */

interface Flyweight
{

    /**
     * @param string $extrinsicState
     * @param $intrinsicState
     * @return mixed
     */
    public static function operation(string $extrinsicState,$intrinsicState);

    /**
     * @param string $extrinsicState
     * @param $intrinsicState
     * @return mixed
     */
    public function unoperation(string $extrinsicState);

}
