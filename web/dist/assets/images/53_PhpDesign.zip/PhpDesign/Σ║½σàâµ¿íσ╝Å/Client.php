<?php


namespace app;
require __DIR__ . '/./vendor/autoload.php';

class Client
{
    public function index() {
        $factory = new FlyweightFactory('ConcreteFlyweight');
        $concreteFlyweight = $factory->get('ConcreteFlyweight',ConcreteFlyweight::class);

        $unsharedConcreteFlyweight = $factory->getUnshared('UnsharedConcreteFlyweight');

        return [
            $concreteFlyweight['ConcreteFlyweight']::operation(1,0),
            $unsharedConcreteFlyweight->unoperation(1)
        ];

    }

}

(new Client())->index();



