<?php

/**
 * 非共享具体享元类
 * 并不是所有的抽象享元子类都需要被共享，不能被共享的子类可设计为非共享具体享元类，当需要一个非具体享元对象时可以直接实例化创建
 */
namespace app;


class UnsharedConcreteFlyweight implements Flyweight
{

    /**
     * @param string $extrinsicState
     * @param $intrinsicState
     * @return mixed
     */
    public static function operation(string $extrinsicState,$intrinsicState)
    {
        // TODO: Implement operation() method.

    }

    /**
     * @param string $extrinsicState
     * @param $intrinsicState
     * @return mixed
     */
    public function unoperation(string $extrinsicState)
    {
        // TODO: Implement unoperation() method.
        print_r("非共享具体享元操作");
        print_r("外部状态:".$extrinsicState);
    }
}
