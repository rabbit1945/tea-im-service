<?php


namespace app;




class FlyweightFactory implements \Countable
{


    private $pool = [];

    public $flyweight;
    public function __construct($class_name)
    {
        $this->flyweight = $class_name;
    }


    public function get(string $k,$name) {

        if (!isset($this->pool[$k])) {

            $this->pool[$k] = $name;

        }

        return $this->pool;

    }

    public function getUnshared( $name){

        return new UnsharedConcreteFlyweight();

    }



    /**
     * @return int
     */
    public function count()
    {
        // TODO: Implement count() method.
        return count($this->pool);
    }
}
