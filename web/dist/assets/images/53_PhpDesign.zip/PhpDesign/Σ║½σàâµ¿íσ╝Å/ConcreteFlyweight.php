<?php
/**
 * 定义具体享元类
 * 实现/继承抽象共享类，实例称为共享对象，在具体享元类中为内部状态提供了存储空间，通常可以结合单例模式来设计具体享元类
 */

namespace app;


class ConcreteFlyweight implements Flyweight
{
    /**
     * 初始化状态
     * @var
     */
    private static $intrinsicState =1;

    private function __construct(){}


    /**
     * @param string $extrinsicState
     * @param $intrinsicState
     * @return mixed
     */
    public static function operation(string $extrinsicState,$intrinsicState)
    {
        // TODO: Implement operation() method.
        $intrinsicState = $intrinsicState ? $intrinsicState :self::$intrinsicState;
        print_r("具体享元操作");
        print_r("内部状态:".$intrinsicState);
        print_r("外部状态:".$extrinsicState);

    }

    private function __clone(){}

    /**
     * @param string $extrinsicState
     * @param $intrinsicState
     * @return mixed
     */
    public function unoperation(string $extrinsicState, $intrinsicState)
    {
        // TODO: Implement unoperation() method.
    }
}
