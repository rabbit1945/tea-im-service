<?php
/**
 * 适配器类
 * Class MediaAdapter
 */


require_once './MediaPlayer.php';
require_once './Mp4.php';
require_once './Vlc.php';

class MediaAdapter  implements MediaPlayer
{

    private $playMp4;
    private $playVlc;
    public function __construct(){

        $this ->playMp4 = new Mp4();
        $this ->playVlc  = new Vlc();
    }

    public function play($audioType, $fileName)
    {

        if ($audioType == 'Mp4') {
            $mp4 = $this ->playMp4->playMp4($fileName);
            print_r("播放Mp4{$mp4}");

        } elseif ($audioType == 'Vlc') {
            $vlc = $this ->playVlc->playVlc($fileName);
            print_r("播放Vlc{$vlc}");

        }



    }


}
