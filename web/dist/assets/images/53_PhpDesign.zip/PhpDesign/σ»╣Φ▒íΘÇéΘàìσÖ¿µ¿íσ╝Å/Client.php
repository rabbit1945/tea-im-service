﻿<?php


require_once './MediaAdapter.php';



class Client
{

    public $adapter;

    public function __construct(MediaAdapter $mediaAdapter) {
        $this->adapter = $mediaAdapter;
    }


    public function play() {

        $this->adapter->play('Mp4','test.mp4');
        $this->adapter->play('Vlc','test.vlc');

    }

}


(new Client(new MediaAdapter()))->play();
