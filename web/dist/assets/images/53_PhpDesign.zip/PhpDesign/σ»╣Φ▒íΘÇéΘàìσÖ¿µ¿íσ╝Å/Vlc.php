<?php
/**
 * vlc 实体类
 */

use Client;

require_once './AdvancedMediaPlayer.php';

class Vlc implements AdvancedMediaPlayer
{
    public function __construct()
    {
    }

    /**
     * @param $fileName
     * @return mixed
     */
    public function playVlc($fileName)
    {
        // TODO: Implement playVlc() method.
        return $fileName;
    }

    /**
     * @param $fileName
     * @return mixed
     */
    public function playMp4($fileName)
    {
        // TODO: Implement playMp4() method.
        return NULL;

    }
}
