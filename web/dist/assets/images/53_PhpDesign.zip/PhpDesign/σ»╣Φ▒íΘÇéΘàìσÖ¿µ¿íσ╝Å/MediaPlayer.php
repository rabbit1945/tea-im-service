<?php
/**
 * 媒体播放器接口 播放 MP4 和 vlc
 * Interface MediaPlayer
 */

interface MediaPlayer
{
    /**
     * @param $audioType  //类型
     * @param $fileName  //名称
     * @return mixed
     */
    public function play($audioType, $fileName);

}
