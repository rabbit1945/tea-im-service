<?php
/**
 * 调度者或管理者。负责建造的流程
 * Class HouseDirector
 */

class HouseDirector
{
    private  $houseBuilder;

    public function __construct($builder)
    {
        $this->houseBuilder = $builder;

    }

    //  管理者可以指定工作流程。返回结果
    public function constructHouse()
    {
        $this->houseBuilder->basic();
        $this->houseBuilder->walls();
        $this->houseBuilder->roofed();

        return $this->houseBuilder->GetResult();

    }


}
