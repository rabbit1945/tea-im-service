<?php
/**
 * 创建一个具体建造者（实体类），根据抽象方法建造一个高层房子
 */
require_once './Builder.php';
class HighBuilder extends Builder
{

    public function basic()
    {
        // TODO: Implement basic() method.
        $this->house->add("高层房子打20米的地基");
    }

    public function walls()
    {
        // TODO: Implement walls() method.
        $this->house->add("高层房子砌墙厚度20cm");

    }

    public function roofed()
    {
        // TODO: Implement roofed() method.
        $this->house->add("高层房子屋顶");
    }
}
