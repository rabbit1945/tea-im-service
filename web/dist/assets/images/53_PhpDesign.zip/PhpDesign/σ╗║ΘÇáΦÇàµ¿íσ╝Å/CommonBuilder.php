<?php
/**
 * 创建一个具体建造者（实体类），根据抽象方法建造一个普通房子
 */
require_once './Builder.php';
class CommonBuilder extends Builder {

    public function basic() {
      $this->house->add("普通房子打十米的地基");
    }

    public function walls() {
        $this->house->add("普通房子砌墙厚度10cm");
    }

    public function roofed() {
        $this->house->add("普通房子屋顶");
    }


}
