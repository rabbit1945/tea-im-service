<?php

/**
 * 创建一个产品，用$parts属性组装不同的组件，成一个产品
 * Class House
 */
class House {
    /**
     * 组件列表
     * @var array
     */
    private  $parts = [];

    /**
     * 添加组件
     * @param $part
     */
    public function add($part) {
        $this->parts[] = $part;
    }

    /**
     * 显示产品需要的组件
     */
    public function show() {
        echo PHP_EOL . '产品创建'.PHP_EOL;
        foreach ($this->parts as $part){
            echo $part, PHP_EOL;
        }
    }

}
