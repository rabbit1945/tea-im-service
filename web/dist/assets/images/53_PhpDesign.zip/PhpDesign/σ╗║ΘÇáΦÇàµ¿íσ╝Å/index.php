<?php


require_once './CommonBuilder.php';
require_once './HighBuilder.php';
require_once './HouseDirector.php';
// 用户盖普通房子
$common = new CommonBuilder();

//管理者来安排具体流程
$director = new HouseDirector($common);

$director->constructHouse()->show();
//================================================高层房子=======================

// 高层房子
$high = new HighBuilder();
//管理者来安排具体流程
$director = new HouseDirector($high);
//显示结果
$director->constructHouse()->show();






