<?php
/**
 * 盖房子抽象类 步骤：打地基 砌墙 盖房顶
 * 角色：抽象建造者
 * Class Builder
 */
require_once './House.php';

abstract class Builder {

    protected  $house;

    public function __construct()
    {
        $this->house = new House();
    }

    //建造流程写好
    public abstract function basic();
    public abstract function walls();
    public abstract function roofed();

    //房子建造好， 将产品（房子）返回

    public function GetResult(): House
    {


        return $this->house;
    }

}
