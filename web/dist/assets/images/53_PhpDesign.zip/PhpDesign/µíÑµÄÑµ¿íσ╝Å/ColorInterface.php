<?php
/**
 * 实现 颜色接口类
 * Interface ColorInterface
 */

interface ColorInterface
{
    /**
     * @return mixed
     */
    public function getInfo();

}
