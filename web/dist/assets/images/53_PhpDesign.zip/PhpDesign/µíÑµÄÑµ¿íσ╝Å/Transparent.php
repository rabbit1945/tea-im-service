<?php
/**
 * 透明
 * Class Transparent
 */
require_once './ColorInterface.php';
class Transparent implements ColorInterface
{

    /**
     * @return mixed
     */
    public function getInfo()
    {
        // TODO: Implement getInfo() method.
        return "透明";

    }
}
