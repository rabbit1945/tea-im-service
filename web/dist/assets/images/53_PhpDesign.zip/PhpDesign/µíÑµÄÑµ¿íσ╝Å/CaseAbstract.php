<?php
/**
 * 机箱抽象类
 * Class CaseAbstract
 */
require_once './ColorInterface.php';
abstract class CaseAbstract
{
    /**
     * @var
     */
    protected $color;

    public function __construct(ColorInterface $color) {
        $this->color = $color;
    }

    /**
     * 运行机箱
     * @return mixed
     */
    abstract public function run();



}
