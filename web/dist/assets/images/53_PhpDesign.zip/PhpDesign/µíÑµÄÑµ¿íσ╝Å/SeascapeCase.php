<?php
/**
 * 海景房机箱 （抽象类）
 * Class SeascapeCase
 */
require_once './CaseAbstract.php';
class SeascapeCase extends CaseAbstract
{

    public function run()
    {
        // TODO: Implement run() method.
        return $this->color->getInfo().'海景房机箱';
    }
}
