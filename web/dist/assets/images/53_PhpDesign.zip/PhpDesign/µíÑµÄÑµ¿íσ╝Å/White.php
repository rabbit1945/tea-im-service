<?php

/**
 * 白色
 * Class White
 */
require_once './ColorInterface.php';
class White implements ColorInterface
{

    /**
     * @return mixed
     */
    public function getInfo()
    {
        // TODO: Implement getInfo() method.
        return '白色';
    }
}
