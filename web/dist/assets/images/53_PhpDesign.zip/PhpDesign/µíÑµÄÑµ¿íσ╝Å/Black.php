<?php
/**
 * 黑色
 * Class Black
 */
require_once './ColorInterface.php';
class Black implements ColorInterface
{

    public function getInfo()
    {
        // TODO: Implement getInfo() method.
        return '黑色';
    }
}
