<?php

/**
 * 默认机箱 （抽象类）
 * Class DefaultCase
 */
require_once'./CaseAbstract.php';
class DefaultCase extends CaseAbstract
{

    public function run()
    {
        // TODO: Implement run() method.
        return $this->color->getInfo().'默认机箱';

    }
}
