<?php
/**
 * 异形机箱类
 */
require_once './CaseAbstract.php';
class AlienCase extends CaseAbstract
{

    public function run()
    {
        // TODO: Implement run() method.
        return $this->color->getInfo().'异形机箱';
    }
}


