<?php
/**
 * 客户端
 * Class Client
 */

require_once './White.php';
require_once './Black.php';
require_once './DefaultCase.php';
require_once './AlienCase.php';
require_once './SeascapeCase.php';
class Client
{
    /**
     * 给机箱添加颜色
     */
    public function index() {
        $white = new White();
        $black = new Black();

        // 给异形机箱添加颜色
        $alienCase = new AlienCase($white);
        echo $alienCase->run(). PHP_EOL;;


        $transparent = new SeascapeCase($black);
        echo $transparent->run(). PHP_EOL;





    }

}


(new Client())->index();


