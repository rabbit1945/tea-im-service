<?php
/**
 * 适配器类
 * Class MediaAdapter
 */
require_once './MediaPlayer.php';
require_once './Mp4.php';
class MediaAdapterMp4 extends Mp4 implements MediaPlayer
{


    public function play($audioType, $fileName)
    {

        if ($audioType == 'Mp4') {
            $mp4 = self::playMp4($fileName);
            print_r("播放Mp4{$mp4}");

        }


    }


}
