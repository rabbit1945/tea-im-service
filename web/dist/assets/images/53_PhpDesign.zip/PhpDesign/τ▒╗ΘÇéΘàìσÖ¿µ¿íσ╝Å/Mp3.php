<?php

require_once './MediaPlayer.php';
class Mp3 implements MediaPlayer
{
    public function __construct()
    {
    }

    /**
     * @param $audioType
     * @param $fileName
     * @return mixed
     */
    public function play($audioType, $fileName)
    {
        // TODO: Implement play() method.
        return $fileName;

    }
}
