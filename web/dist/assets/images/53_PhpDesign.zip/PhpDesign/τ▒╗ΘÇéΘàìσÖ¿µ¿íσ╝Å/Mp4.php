<?php
/**
 * MP4 实体类
 */
require_once './AdvancedMediaPlayer.php';

class Mp4 implements AdvancedMediaPlayer
{
    public function __construct()
    {
    }

    /**
     * @param $fileName
     * @return mixed
     */
    public function playVlc($fileName)
    {
        // TODO: Implement playVlc() method.
        return null;
    }

    /**
     * @param $fileName
     * @return mixed
     */
    public function playMp4($fileName)
    {
        // TODO: Implement playMp4() method.
        return $fileName;

    }
}
