<?php
require_once './MediaAdapterMp4.php';

$adapterMp4 = new MediaAdapter();

$adapterMp4->play('Mp4','test.mp4');

