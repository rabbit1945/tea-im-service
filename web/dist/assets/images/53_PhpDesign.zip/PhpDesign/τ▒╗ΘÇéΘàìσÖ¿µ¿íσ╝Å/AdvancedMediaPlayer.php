<?php
/**
 * 被适配器的接口,也可以理解为其他厂家的接口。播放vlc 和 mp4
 * Interface AdvancedMediaPlayer
 */

interface AdvancedMediaPlayer
{
    public function playVlc($fileName);
    public function playMp4($fileName);
}


