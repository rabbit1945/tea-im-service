<?php


namespace app;
/**
 * CSV 迭代器
 * Class CsvIterator
 * @package app
 */

class CsvIterator implements \Iterator
{
    const ROW_SIZE = 4096;
    /**
     * @var false|resource
     */
    private $filePointer;
    /**
     * 分隔符
     * @var mixed|string
     */
    private $delimiter;
    /**
     * @var int
     */
    protected $rowCounter = 0;
    protected $currentElement;

    public function __construct($file, $delimiter = ',') {
        try {

            $this->filePointer = fopen($file, 'rb');
            $this->delimiter = $delimiter;


        } catch (\Exception $e) {
            throw new \Exception('The file "' . $file . '" cannot be read.');
        }

    }

    /**
     * 返回当前元素
     * @return mixed
     */
    public function current()
    {
        // TODO: Implement current() method.
        // 解析一行数据
        $currentElement = fgetcsv($this->filePointer,self::ROW_SIZE,$this->delimiter);

//        if ($currentElement ) {
//            $data = [];
//            foreach ($currentElement as  $val) $data[] = iconv('gbk','utf-8',$val);
//            $this->currentElement = $data;
//            $this->rowCounter++;
//        }

        $this->currentElement = $currentElement;
        $this->rowCounter++;
        return $this->currentElement;
    }

    /**
     * 向前移动到下一个元素
     */
    public function next()
    {
        // TODO: Implement next() method.

        if (is_resource($this->filePointer)) {
            return !feof($this->filePointer);
        }

        return false;
    }

    /**
     * 返回当前元素的键
     * @return bool|float|int|string|null
     */
    public function key()
    {
        // TODO: Implement key() method.
        return $this->rowCounter;
    }

    /**
     * 检查当前位置是否有效
     * @return bool
     */
    public function valid(): bool
    {
        // TODO: Implement valid() method.
        if (!$this->next()) {
            if (is_resource($this->filePointer)) {

                fclose($this->filePointer);
            }
            return false;
        }

        return true;

    }

    /**
     * 返回到迭代器的第一个元素
     */
    public function rewind()
    {
        // TODO: Implement rewind() method.
        $this->rowCounter = 0;
        rewind($this->filePointer);
    }
}
