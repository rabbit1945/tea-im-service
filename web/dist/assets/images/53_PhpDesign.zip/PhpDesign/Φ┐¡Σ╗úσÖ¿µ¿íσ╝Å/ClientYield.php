<?php


namespace app;
use Exception;
header('Content-type:text/html;charset=utf-8');

require __DIR__ . '/./vendor/autoload.php';

class Client
{




    public function getLinesFromFile() {

        if (!$fileHandle = fopen(__DIR__ . '/product.csv', 'rb')) {
            return;
        }
        while (false !== $line = fgetcsv($fileHandle,4096)) {

            yield $line;

        }

        fclose($fileHandle);

    }



}

ini_set('memory_limit', '512M');


$start_time=microtime(true);

$getLinesFromFile = (new Client())->getLinesFromFile();
$data = [];
foreach($getLinesFromFile as $val){
    $data[] = $val;
}
$end_time=microtime(true);
echo "time: ", bcsub($end_time, $start_time, 4), "\n";
echo "memory (byte): ", memory_get_peak_usage(true), "\n";











