<?php


namespace app;
use Exception;
header('Content-type:text/html;charset=utf-8');

require __DIR__ . '/./vendor/autoload.php';

class Client
{


    /**
     * @throws Exception
     */
    public function index() {
        $csv = new CsvIterator(__DIR__ . '/product.csv');
        $data = [];
        foreach ($csv as $key => $row) {

            $data[] = $row;
        }

        return $data;

    }


}


$start_time=microtime(true);
//
try {
    (new Client())->index();
} catch (Exception $e) {
    echo $e->getMessage();
}
$end_time=microtime(true);
echo "time: ", bcsub($end_time, $start_time, 4), "\n";
echo "memory (byte): ", memory_get_peak_usage(true), "\n";



