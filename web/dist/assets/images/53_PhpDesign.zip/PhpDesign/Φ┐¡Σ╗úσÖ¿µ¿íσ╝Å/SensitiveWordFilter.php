<?php


namespace app;


class SensitiveWordFilter
{
    /**
     * 字典
     * @var array
     */
    protected array $dict;
    /**
     * 字典路径
     * @var
     */
    protected $dictFile;

    public function __construct($dictFile)
    {
        $this->dictFile = $dictFile;
        $this->dict = [];
    }



}
