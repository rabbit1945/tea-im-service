<?php
/**
 * 门面模式
 * 负责将"分散"的功能提供统一接口
 * Class Facade
 */
require_once './Camera.php';
require_once './Light.php';
require_once './Sensor.php';
require_once './Alarm.php';
class Facade
{
    /* 录像机 */
    private static $_camera;

    /* 灯 */
    private static $_light;

    /* 感应器 */
    private static $_sensor;

    /* 警报器 */
    private static $_alarm;

    public function __construct()
    {
    }

    /**
     * 获取实例的接口
     */

    private static function getInstance()
    {

        self::$_camera = self::$_camera ? self::$_camera : new Camera();
        self::$_light = self::$_light ? self::$_light: new Light();
        self::$_sensor = self::$_sensor ? self::$_sensor :new Sensor();
        self::$_alarm = self::$_alarm ? self::$_alarm : new Alarm();

    }


    /**
     * 启动接口: (打开录像机/开灯/启动感应器/启动报警器)
     * @return void
     */
    public static function activate()
    {
        self::getInstance();
        // 打开录像机
        self::$_camera -> turnOn();
        // 开灯
        self::$_light -> turnOn();
        // 启动感应器
        self::$_sensor -> activate();
        // 启动报警器
        self::$_alarm -> activate();
        // 分隔符(方便观察)
        echo '<hr>';
    }

    /**
     * 关闭接口: (关闭录像机/关灯/关闭感应器/关闭报警器)
     * @return void
     */
    public static function deactivate()
    {
        self::getInstance();
        // 关闭录像机
        self::$_camera -> turnOff();
        // 关灯
        self::$_light -> turnOff();
        // 关闭感应器
        self::$_sensor -> deactivate();
        // 关闭报警器
        self::$_alarm -> deactivate();
        // 分隔符(方便观察)
        echo '<hr>';
    }








}
