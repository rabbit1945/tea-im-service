<?php
/**
 * 报警器
 * Class Alarm
 *
 */
class Alarm
{

    /**
     * 启动警报器
     */
    public function activate()
    {
        echo "启动报警器" . '<br/>';
    }

    /**
     * 关闭警报器
     */
    public function deactivate()
    {
        echo "关闭报警器" . '<br/>';
    }


    /**
     * 拉响警报器
     */
    public function ring()
    {
        echo "拉响报警器" . '<br/>';
    }

    /**
     * 停掉警报器
     */
    public function stopRing()
    {
        echo "停掉报警器" . '<br/>';
    }

}
