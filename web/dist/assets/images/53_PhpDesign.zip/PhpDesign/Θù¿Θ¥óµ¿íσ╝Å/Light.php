<?php
/**
 * 灯类
 * Class Light
 */

class Light
{

    public function turnOn() {
        echo "打开灯光". '<br/>';
    }

    public function turnoff() {
        echo "关闭灯光". '<br/>';
    }


    public function changeBulb()
    {
        echo "换灯泡" . '<br/>';
    }

}
