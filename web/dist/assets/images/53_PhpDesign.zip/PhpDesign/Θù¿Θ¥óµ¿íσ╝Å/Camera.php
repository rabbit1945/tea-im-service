<?php
/**
 * 摄像机类
 * Class Camera
 */

class Camera
{

    public function turnOn() {
        echo "打开录像机". '<br/>';
    }

    public function turnoff() {
        echo "关闭摄像机". '<br/>';
    }



}
