<?php

require_once 'Facade.php';
class Client
{

    public function index()
    {
        // TODO: Implement playVlc() method.
        Facade::activate();
        Facade::deactivate();

    }

}

(new Client()) -> index();
