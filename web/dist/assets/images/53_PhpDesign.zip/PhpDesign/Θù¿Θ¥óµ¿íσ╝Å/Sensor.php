<?php
/**
 * 感应器
 * Class Sensor
 */

class Sensor
{
    /**
     * 启动感应器
     */
    public function activate()
    {
        echo "启动感应器" . '<br/>';
    }

    /**
     * 关闭感应器
     */
    public function deactivate()
    {
        echo "关闭感应器" . '<br/>';
    }

    /**
     * 触发感应器
     */
    public function trigger()
    {
        echo "触发感应器" . '<br/>';
    }


}
