<?php


namespace app;


interface Command
{
    /**
     * @return mixed
     */
    public function execute();

}
