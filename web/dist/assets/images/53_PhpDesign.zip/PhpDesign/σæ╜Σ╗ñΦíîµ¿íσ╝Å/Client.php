<?php


namespace app;
require __DIR__ . '/./vendor/autoload.php';

class Client
{
    public function index() {
        //  调用类
        $invoker = new Invoker();
        // 接受类
        $receiver = new Receiver();
        $invoker->setCommand(new HelloCommand($receiver));

        $messageDateCommand = new AddMessageDateCommand($receiver);
        $messageDateCommand->execute();

        $invoker->run();

        print_r($receiver->getOutput());



    }
}

(new Client())->index();
