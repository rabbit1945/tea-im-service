<?php


namespace app;


interface UndoableCommand extends Command
{

    /**
     * 撤销
     * @return mixed
     */
    public function undo();

}
