<?php


namespace app;


class AddMessageDateCommand implements UndoableCommand
{

    private $output;

    public function __construct( Receiver $output)
    {
        $this->output = $output;

    }

    /**
     * 开启
     * @return mixed
     */
    public function execute()
    {

        // TODO: Implement execute() method.
        $this->output->enableDate();
    }

    /**
     * 关闭
     * @return mixed
     */
    public function undo()
    {
        // TODO: Implement undo() method.
        $this->output->disableDate();
    }
}
