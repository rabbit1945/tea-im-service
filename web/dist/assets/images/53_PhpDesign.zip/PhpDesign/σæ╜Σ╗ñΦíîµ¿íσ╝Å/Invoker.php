<?php


namespace app;
/**
 * 调用类
 * Class Invoker
 * @package app
 */

class Invoker
{
    public  $command;

    public function setCommand( $cmd)
    {
        $this->command = $cmd;
    }

    public function run()
    {
        $this->command->execute();

    }

    public function undo(){
        $this->command->undo();

    }


}
