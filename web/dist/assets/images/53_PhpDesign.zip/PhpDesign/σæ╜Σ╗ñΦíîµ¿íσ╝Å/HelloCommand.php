<?php


namespace app;


class HelloCommand implements Command
{
    private $output;

    public function __construct( Receiver $output)
    {
        $this->output = $output;

    }
    /**
     * @return mixed
     */
    public function execute()
    {
        // TODO: Implement execute() method.
        $this->output->write('Hello World');

    }


}
