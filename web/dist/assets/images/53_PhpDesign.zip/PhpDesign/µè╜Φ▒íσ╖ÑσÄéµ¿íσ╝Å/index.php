<?php
require_once './Factory.php';

$factory = new Factory();
//获取颜色工厂类
$colorFactory = $factory->getFactory('ColorFactory');
$colorFactory->getColor('Red')->fill();
$colorFactory->getColor('Green')->fill();
$colorFactory->getColor('Blue')->fill();

// 绘制形状工厂类
$shapeFactory = $factory->getFactory('ShapeFactory');
$shapeFactory->getShape('Circle')->draw();

$shapeFactory->getShape('Square')->draw();
$shapeFactory->getShape('Rectangle')->draw();

