<?php

/**
 * 创建工厂类
 * Class Factory
 */
require_once './ColorFactory.php';
require_once './ShapeFactory.php';
class Factory
{
    public function getFactory($className){

        $className = ucfirst($className);
        if ($className and class_exists($className)) {
            return new $className();
        }
        return False;

    }

}
