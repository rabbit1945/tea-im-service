<?php
/**
 * 创建颜色工厂类
 * Class ColorFactory
 */
require_once './Red.php';
require_once './Blue.php';
require_once './Green.php';
require_once './AbstractFactory.php';
class ColorFactory extends AbstractFactory
{
    public function getColor($className){

        $className = ucfirst($className);
        if ($className and class_exists($className)) {
            return new $className();
        }
        return False;
    }

    public function getShape($className): bool
    {
        return False;
    }

}
