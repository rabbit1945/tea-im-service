<?php
/**
 * 创建一个图形工厂类
 * Class ShapeFactory
 */
require_once './Circle.php';
require_once './Square.php';
require_once './Rectangle.php';
require_once './AbstractFactory.php';
class ShapeFactory extends AbstractFactory
{

    public function getShape($className) {

        $className = ucfirst($className);
        if ($className && class_exists($className)) {

            return new $className();
        }
        return False;
    }
    public function getColor($className): bool
    {
        // TODO: Implement getColor() method.
        return False;
    }
}
