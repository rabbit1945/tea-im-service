<?php

/**
 * 颜色接口
 * Interface Color
 */

interface Color {
    /**
     * 填充方法
     * @return mixed
     */

    public function fill();
}
