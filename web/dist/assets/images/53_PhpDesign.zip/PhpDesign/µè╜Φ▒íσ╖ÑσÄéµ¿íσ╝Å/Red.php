<?php
/**
 * 创建绿红颜色的实体类
 */
require_once './Color.php';


class Red implements Color
{
    public function fill()
    {
        print_r("填充红颜色");

    }

}
