<?php
/**
 * 创建蓝颜色的实体类
 * Class Blue
 */

class Blue implements Color
{
    public function fill()
    {
        // TODO: Implement fill() method.
        print_r("创建蓝颜色实体类");
    }

}
