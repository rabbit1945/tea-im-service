<?php



namespace App;

require __DIR__ . '/../vendor/autoload.php';
use App\Udp as sp;

class Client
{
    public function index() {

         (new sp())->index();
    }

}

(new Client()) -> index();
