<?php


namespace App;


class Space
{
    public function index() {
        echo "命名空间1";
    }

}
