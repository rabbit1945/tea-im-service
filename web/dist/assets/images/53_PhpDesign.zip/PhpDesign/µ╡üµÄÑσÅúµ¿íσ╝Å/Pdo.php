<?php

/**
 * 定义抽象方法
 */
namespace db;


abstract  class Pdo
{
    /**
     * 字段
     * @param $fields
     * @return mixed
     */
    abstract public function field($fields);

    /**
     * @param $table //表名
     * @param $alias // 别名
     * @return mixed
     */
    abstract public function table($table, $alias);

    /**
     * @param $condition // 条件
     * @return mixed
     */
    abstract public function where($condition);

    /**
     * 查询列表
     * @return mixed
     */
    abstract public function select();

}
