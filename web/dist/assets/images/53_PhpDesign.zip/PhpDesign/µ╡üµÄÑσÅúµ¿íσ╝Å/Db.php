<?php
namespace db;

class Db extends Pdo
{
    /**
     * 字段
     * @var array
     */
    private $fields = [];

    /**
     * 表
     * @var array
     */
    private $table = [];

    /**
     * 条件
     * @var array
     */
    private $where = [];

    /**
     * @param $fields
     * @return Db
     */
    public function field($fields) {

        $this->fields[] = $fields;

        return $this;
    }

    /**
     * 表
     * @param $table
     * @param $alias
     * @return $this
     */
    public function table($table, $alias = NULL) {
        $alias = $alias?$alias:$table;
        $this->table[] = $table .' as '.$alias;
        return $this;
    }

    /**
     * 条件
     * @param $condition
     * @return $this
     */
    public function where($condition) {
        $this->where[] = $condition;
        return $this;
    }

    public function select()
    {

        // TODO: Implement __toString() method.
        return sprintf(
            'SELECT %s FROM %s WHERE %s',
            join(', ', $this->fields),
            join(', ', $this->table),
            join(' AND ', $this->where)
        );

    }


}
