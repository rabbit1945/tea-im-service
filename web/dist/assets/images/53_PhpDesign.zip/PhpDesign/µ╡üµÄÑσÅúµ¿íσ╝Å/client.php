<?php
namespace db;
require __DIR__ . '/./vendor/autoload.php';


class client
{
    public function index() {
        $sql = (new Db())->table('xiao')->field('id,name')->where('1=1')->select();
        echo $sql;

    }

}

(new client())->index();
