<?php


namespace App\udp;
use Swoole;

class Udp
{
    /**
     * 
     */
    public function service() {
        $server = new Swoole\Server('0.0.0.0', 9503, SWOOLE_PROCESS, SWOOLE_SOCK_UDP);

        //监听数据接收事件。
        $server->on('Packet', function ($server, $data, $clientInfo) {
            var_dump($clientInfo);
            $server->sendto($clientInfo['address'], $clientInfo['port'], "Server：{$data}");
        });

        //启动服务器
        $server->start();

    }

    /**
     *
     */

    public function client() {
        $client = new Swoole\Client(SWOOLE_SOCK_UDP);
        if (!$client->connect('0.0.0.0', 9503, -1)) {
            exit("connect failed. Error: {$client->errCode}\n");
        }
        $client->send("hello world\n");
        echo $client->recv();
        $client->close();
    }

}
