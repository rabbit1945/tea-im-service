<?php


namespace App;

require __DIR__ . '/../../vendor/autoload.php';
use App\udp\Udp as Udp;

class Client
{
    public function index() {

        return (new Udp())->client();
    }

}

(new Client()) -> index();
