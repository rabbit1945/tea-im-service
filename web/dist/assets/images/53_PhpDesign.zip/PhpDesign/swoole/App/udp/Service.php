<?php



namespace App;

require __DIR__ . '/../../vendor/autoload.php';
use App\udp\Udp as Udp;

class Service
{
    public function index() {

         (new Udp())->service();
    }

}

(new Service()) -> index();
