<?php

/**
 * Class InterruptedException
 */
class InterruptedException extends \Exception
{

}