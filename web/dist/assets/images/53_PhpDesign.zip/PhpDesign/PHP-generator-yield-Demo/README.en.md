# PHP Generator Yield Demo

#### Description
PHP 生成器 yield 语法Demo

#### Software Architecture
Software architecture description


#### Instructions

```shell

php ./whatIsGenerator.php

php ./generatorMethod.php

```
