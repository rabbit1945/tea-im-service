<?php
require_once './SingleObject.php';
$instance = SingleObject::getInstance();

$instance->showMessage();
