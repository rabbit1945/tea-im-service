<?php
/**
 * 单例（懒汉）模式
 * Class SingleObject
 */

class SingleObject
{
    /**
     * 属性私有化
     * 保存生产对象
     */
    private static $instance;
    /**
     * 构造函数私有化
     * 禁止外部类的实例化
     */
    private function __construct(){}

    /**
     * 获取实例的接口
     */

    public static function getInstance()
    {
        if (!self::$instance instanceof self) {
            self::$instance = new self;
        }
        return self::$instance;

    }
     public function showMessage() {
        print_r("Hello World!!!");
     }

    /**
     * 私有化克隆方法
     * 防止在外部克隆
     */
    private function __clone(){}



}
