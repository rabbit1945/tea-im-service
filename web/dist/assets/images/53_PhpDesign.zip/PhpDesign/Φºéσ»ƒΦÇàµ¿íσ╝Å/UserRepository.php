<?php

namespace app;
use SplObserver;

/**
 * 被观察者类
 * Class UserRepository
 * @package app
 */
class UserRepository implements \SplSubject
{
    /**
     * 用于存储观察者对象
     * @var
     */
    public $observers = [];

    private function initEventGroup(string $event = "*"): void
    {
        if (!isset($this->observers[$event])) {
            $this->observers[$event] = [];
        }
    }



    /**
     * 注册观察者对象
     * @param SplObserver $observer
     * @param string $event
     */
    public function attach(SplObserver $observer,$event = "*")
    {
        $this->initEventGroup($event);
        // TODO: Implement attach() method.
        $this->observers[$event][] = $observer;
    }


    /**
     * 删除观察者对象
     * @param SplObserver $observer
     * @param string $event
     * @return false
     */
    public function detach(SplObserver $observer,$event = "*")
    {
        $this->initEventGroup($event);
        // TODO: Implement detach() method.
        $index = array_search($observer,$this->observers);

        if (!$index) return false;

        unset($this->observers[$index]);

    }





    /**
     * 发送通知
     * @param string $event
     * @param null $data
     */
    public function notify(string $event = "*", $data = null)
    {


        $this->initEventGroup($event);
        $group = $this->observers[$event];
        $all = $this->observers["*"];
        if ($group == $all ) $all = [];
        $observersData = array_merge($group, $all);

        foreach ($observersData as $key=> $observer) {

            $observer->update($this, $event, $data);

        }

    }




    public function createUser(array $data): Users
    {

        $user = new Users();
        $user->update($data);
        $this->notify("user::create", $user);
        return $user;
    }
}
