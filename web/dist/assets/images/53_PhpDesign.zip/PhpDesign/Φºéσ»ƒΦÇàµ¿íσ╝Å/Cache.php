<?php

namespace app;
use SplSubject;

/**
 * 缓存观察者类
 * Class cache
 * @package app
 */
class Cache implements \SplObserver
{

    private $filename = __DIR__ . "/cache.txt";
    /**
     * 更新缓存
     * @param SplSubject $subject
     * @param string $event
     * @param null $data
     */
    public function update(SplSubject $subject,string $event = "*", $data = null)
    {
        // TODO: Implement update() method.
        $entry = 'cache'.json_encode($data);
        file_put_contents($this->filename, $entry, FILE_APPEND);
        return $entry;
    }
}
