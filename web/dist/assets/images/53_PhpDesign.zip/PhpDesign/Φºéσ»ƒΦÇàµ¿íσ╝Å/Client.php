<?php


namespace app;
require __DIR__ . '/./vendor/autoload.php';

class Client
{
    public function index() {
        $repository = new UserRepository();
        $repository->attach(new Cache(),'*');
        $repository->attach(new Logger(),'*');

        $repository->createUser([
            "name" => "万小明",
            "email" => "wang@example.com",
        ]);


    }

}

$client = (new Client())->index();




