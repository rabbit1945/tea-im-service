<?php
require_once './ShapeFactory.php';

$factory = new ShapeFactory();

// 绘制形状工厂类
$factory->getShape('Circle')->draw();

$factory->getShape('Square')->draw();
$factory->getShape('Rectangle')->draw();

