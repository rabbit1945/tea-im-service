<?php
/**
 * 绘制正方形实体类
 * Class Square
 */
require_once './Shape.php';
class Square implements Shape
{

    /**
     * @inheritDoc
     */
    public function draw()
    {
        // TODO: Implement draw() method.
        print_r("绘制一个正方形");
    }
}
