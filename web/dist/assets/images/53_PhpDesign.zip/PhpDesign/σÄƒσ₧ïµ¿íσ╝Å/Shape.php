<?php
/**
 * 绘制图形接口
 * Interface Shape
 */

interface  Shape
{
    /**
     * 定义绘画接口
     * @return mixed
     */
    public function draw();

}
