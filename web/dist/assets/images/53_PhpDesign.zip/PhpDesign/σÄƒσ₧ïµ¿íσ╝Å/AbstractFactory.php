<?php
/**
 * 定义抽象工厂类
 * Interface AbstractFactory
 */

abstract class AbstractFactory
{
    public abstract function getShape($className);

}
