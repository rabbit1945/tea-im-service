<?php
/**
 * 创建矩形实体类
 * Class Rectangle
 */
require_once './Shape.php';

class Rectangle implements Shape
{

    public function draw()
    {
        // TODO: Implement draw() method.
        print_r("绘制一个矩形");
    }
}
