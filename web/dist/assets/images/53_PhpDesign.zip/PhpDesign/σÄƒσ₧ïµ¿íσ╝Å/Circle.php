<?php
/**
 * 绘制圆形实体类
 * Class Circle
 */
require_once './Shape.php';

class Circle implements Shape
{

    /**
     * @inheritDoc
     */
    public function draw()
    {

        // TODO: Implement draw() method.
        print_r("绘制一个圆形");
    }
}
