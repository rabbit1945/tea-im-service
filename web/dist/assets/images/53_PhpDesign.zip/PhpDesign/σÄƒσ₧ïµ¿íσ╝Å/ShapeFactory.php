<?php
/**
 * 创建一个图形工厂类
 * Class ShapeFactory
 */
require_once './Circle.php';
require_once './Square.php';
require_once './Rectangle.php';
require_once './AbstractFactory.php';
class ShapeFactory extends AbstractFactory
{



    public function getShape($className) {

        $className = ucfirst($className);
        if ($className && class_exists($className)) {
            $newClassName = new $className();
            return clone $newClassName;
        }
        return False;
    }


    public function __clone()
    {
        // TODO: Implement __clone() method.
    }
}
