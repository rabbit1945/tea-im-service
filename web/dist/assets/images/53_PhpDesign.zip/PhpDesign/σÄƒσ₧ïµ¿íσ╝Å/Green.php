<?php
/**
 * 创建绿颜色的实体类
 */
require_once "./Color.php";

class Green implements Color
{
    public function fill()
    {
        print_r("填充绿颜色");
    }

}
