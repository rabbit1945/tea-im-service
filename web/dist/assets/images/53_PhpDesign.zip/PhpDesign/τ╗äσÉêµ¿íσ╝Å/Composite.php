<?php
/**
 * 子部件具体实现类
 * Class Composite
 */
require_once './Component.php';
class Composite extends Component
{
    private $children = [];

    /**
     * @param $c
     * @return mixed
     */
    public function add($c)
    {
        // TODO: Implement add() method.
        $this->children[$c->id] = $c;

    }

    /**
     * @param $c
     * @return mixed
     */
    public function remove($c)
    {
        // TODO: Implement remove() method.
        unset($this->children[$c->id]);
    }

    /**
     * @param $depth
     * @return mixed
     */
    public function display($depth)
    {
        // TODO: Implement display() method.
        $str = str_pad('', $depth , "_");
        echo "{$str} {$this->name}\r\n";
        foreach ($this->children as $c ){
            $c->display($depth+2);
        }
    }
}
