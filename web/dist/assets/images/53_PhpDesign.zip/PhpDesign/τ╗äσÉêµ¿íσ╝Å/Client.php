<?php

require_once './Composite.php';
require_once './Leaf.php';
class Client
{
    public function index() {
        $root = new \Composite(1,'root');
//        $root->add(new \Leaf(2,'2级1'));
//        $root->add(new \Leaf(3,'2级2'));
//        $root->add(new \Leaf(4,'2级3'));
        $two_com = new Composite(5,'2级4');
        $two_com->add(new \Leaf(6,'3级1'));
        $two_com->add(new \Leaf(7,'3级2'));
        $root->add($two_com);

        $root->display(1);
    }

}


(new Client())->index();
