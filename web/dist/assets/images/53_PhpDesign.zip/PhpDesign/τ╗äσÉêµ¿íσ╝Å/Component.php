<?php
/**
 * 定义抽象类 用于显示和管理子部件
 * Class Component
 */

abstract class Component
{
    protected $id;
    protected $name;
    public function __construct($id,$name) {
        $this->id = $id;
        $this->name = $name;
    }

    abstract public function add($c);
    abstract public function remove($c);
    abstract public function display($depth);



}
