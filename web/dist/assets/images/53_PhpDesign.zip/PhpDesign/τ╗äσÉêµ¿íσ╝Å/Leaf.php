<?php
/**
 * 叶子节点
 */
require_once './Component.php';

class Leaf extends Component
{

    /**
     * @param $c
     * @return mixed
     */
    public function add($c)
    {
        // TODO: Implement add() method.
        echo "叶子节点不能添加\r\n";
    }

    /**
     * @param $c
     * @return mixed
     */
    public function remove($c)
    {
        // TODO: Implement remove() method.
        echo "不能删除叶子节点\r\n";
    }

    /**
     * @param $depth
     * @return mixed
     */
    public function display($depth)
    {
        // TODO: Implement display() method.
        $str = str_pad('', $depth , "_");

        echo "{$str} {$this->name}\r\n";
    }
}
